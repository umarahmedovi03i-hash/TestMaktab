package com.testmaktab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TestMaktabApp() }
    }
}

private data class Words(
    val tagline: String, val choose: String, val next: String,
    val loginTitle: String, val username: String, val password: String,
    val signIn: String, val back: String, val version: String
)

private fun words(language: String) = when (language) {
    "Тоҷикӣ" -> Words("Платформаи санҷиш ва рушди дониш", "Забонро интихоб кунед",
        "Идома", "Воридшавӣ", "Номи корбар", "Рамз", "Даромадан", "Бозгашт", "Нусхаи ибтидоӣ 1.1")
    "Русский" -> Words("Платформа проверки и развития знаний", "Выберите язык",
        "Продолжить", "Вход", "Логин", "Пароль", "Войти", "Назад", "Начальная версия 1.1")
    "English" -> Words("A platform for testing and improving knowledge", "Choose a language",
        "Continue", "Sign in", "Username", "Password", "Sign in", "Back", "Initial version 1.1")
    else -> Words("Bilimni sinash va rivojlantirish platformasi", "Tilni tanlang",
        "Davom etish", "Tizimga kirish", "Login", "Parol", "Kirish", "Orqaga", "Boshlang‘ich versiya 1.1")
}

@Composable
fun TestMaktabApp() {
    var language by remember { mutableStateOf("O‘zbekcha") }
    var showLogin by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val languages = listOf("O‘zbekcha", "Тоҷикӣ", "Русский", "English")
    val w = words(language)

    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("TestMaktab", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(w.tagline)
                Spacer(Modifier.height(28.dp))

                if (!showLogin) {
                    Text(w.choose, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    languages.forEach { item ->
                        OutlinedButton(
                            onClick = { language = item },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (language == item) "✓  $item" else item)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { showLogin = true },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(w.next) }
                } else {
                    Text(w.loginTitle, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = username, onValueChange = { username = it },
                        label = { Text(w.username) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        label = { Text(w.password) }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = { },
                        enabled = username.isNotBlank() && password.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(w.signIn) }
                    TextButton(onClick = { showLogin = false }) { Text(w.back) }
                }
                Spacer(Modifier.height(18.dp))
                Text(w.version, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
