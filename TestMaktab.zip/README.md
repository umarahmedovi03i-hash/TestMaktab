# TestMaktab

Android uchun ko‘p tilli test platformasining boshlang‘ich loyihasi.

## Hozirgi holat
- Kotlin va Jetpack Compose
- O‘zbek, tojik, rus va ingliz tillari uchun boshlang‘ich til tanlash ekrani
- GitHub Actions orqali APK yig‘ishga tayyor loyiha

Keyingi bosqichlarda login, profil, fanlar, testlar, natijalar, administrator paneli,
offline Room bazasi va Supabase sinxronizatsiyasi qo‘shiladi.
