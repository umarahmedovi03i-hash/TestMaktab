package com.testmaktab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TestMaktabApp() }
    }
}

@Composable
fun TestMaktabApp() {
    var language by remember { mutableStateOf("O‘zbekcha") }
    val languages = listOf("O‘zbekcha", "Тоҷикӣ", "Русский", "English")
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("TestMaktab", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Bilimni sinash va rivojlantirish platformasi")
                Spacer(Modifier.height(28.dp))
                Text("Tilni tanlang", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                languages.forEach { item ->
                    OutlinedButton(
                        onClick = { language = item },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text(if (language == item) "✓  $item" else item) }
                }
                Spacer(Modifier.height(24.dp))
                Button(onClick = { }, modifier = Modifier.fillMaxWidth()) {
                    Text("Davom etish")
                }
                Spacer(Modifier.height(12.dp))
                Text("Boshlang‘ich versiya 1.0", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
